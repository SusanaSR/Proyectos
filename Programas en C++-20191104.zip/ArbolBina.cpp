//Arbol Binario Ordenado
//El programa est� incompleto. Falta funci�n eliminar nodo y �rbol completo
#include <iostream>

using namespace std;

typedef struct nodo{
    struct nodo *izq;
    int num;
    struct nodo *der;
}nod;

nod *raiz= NULL;

void insertar(struct nodo *aux, int x)
{
     if(aux==NULL)
     {
	    aux = new(nod);
        aux->num = x;
     	aux->izq = NULL;
     	aux->der = NULL;
     	raiz=aux;
     	cout << " El nodo "<< x<<" se inserto en la raiz  ";
     	return;
     }
     if(x < aux->num)
     {
        if(aux->izq==NULL)
        {
         	aux->izq = new(nod);
            aux->izq->num = x;
     		aux->izq->izq = NULL;
     		aux->izq->der = NULL;    
			cout << " El nodo "<< x<<" se inserto en la rama izquierda  ";
			return;                      
        }
        insertar(aux->izq, x);
        
     }
     if(x > aux->num)
     {
        if(aux->der==NULL)
        {
           	aux->der = new(nod);
           	aux->der->num = x;
     	    aux->der->izq = NULL;
     	    aux->der->der = NULL;   
			cout << " El nodo "<< x<<" se inserto en la rama derecha  "; 
			return;                      
        }
        insertar(aux->der, x);         
     }
    if(x == aux->num)
    {
        cout << "\nEl dato ya existe ";	
    }
}

void imprimeArbol(struct nodo *aux, int n)
{
     if(aux==NULL)
	 	return;
	 
	 imprimeArbol(aux->der, n+1);
	 	 
     for(int i=0; i<n; i++) cout<<"   ";
     
     cout<< aux->num <<endl;
     imprimeArbol(aux->izq, n+1);
}
void preOrden(struct nodo *aux)
{
     if(aux!=NULL)
     {
          cout << aux->num <<" ";
          preOrden(aux->izq);
          preOrden(aux->der);
     }
}
void enOrden(struct nodo *aux)
{
     if(aux!=NULL)
     {
          enOrden(aux->izq);
          cout << aux->num << " ";
          enOrden(aux->der);
     }
}

void postOrden(struct nodo *arbol)
{
     if(arbol!=NULL)
     {
          postOrden(arbol->izq);
          postOrden(arbol->der);
          cout << arbol->num << " ";
     }
}
main()
{
    nod *aux = raiz;   
    int n;  // cantidad de nodos que conformar�n arbol
    int x; // elemento a insertar en cada nodo

    cout << "\n\t\t ARBOL BINARIO ORDENADO  \n\n";

    cout << " Numero de nodos del arbol:  ";
    cin >> n;
    cout << endl;
    
    for(int i=0; i<n; i++)
    {
        cout << "\n Numero del nodo " << i+1 << ": ";
        cin >> x;
		aux= raiz;
        insertar(aux, x);   
    }

    cout << endl ;
    system("pause");
    cout << "\n Impresion del arbol \n\n";
    aux = raiz;
    imprimeArbol(aux, 0);
    
    cout << "\n Recorridos ";
    cout << "\n\n Prefijo o preorden  :  "; 
	preOrden(aux);
    cout << "\n\n Infijo o en orden   :  ";   
	enOrden(aux);
    cout << "\n\n Postfijo o Post Orden :  ";   
	postOrden(aux);
    cout<<endl;
    system("pause");
}

