#include<iostream>
#include<stdio.h>
using namespace std;

typedef struct nodito
{
	int dato;
	struct nodito *pt;
}nod;

class Fila
{
	private:
		nod *inic;
	public:
		Fila();
		~Fila();
		void insertarFila(int);
		void sacarFila();
		void imprimeFila();
};

Fila::Fila()
{
	inic=NULL;
}

void Fila::insertarFila(int nd)
{
	nod *aux=inic;
	nod *nvo;
	nvo=new nod;
	nvo->dato=nd;
	nvo->pt=NULL;
	if(inic==NULL)
	{
		inic=nvo;
		return;
	}
	while(aux->pt!=NULL)
	{
		aux=aux->pt;
	}
	aux->pt=nvo;
}

void Fila::sacarFila()
{
	nod *aux=inic;
	if(inic==NULL)
	{
		cout <<"FILA VACIA"<<endl;
		cin.get();
		return;
	}
	inic=aux->pt;
	cout << "Sale "<< aux->dato <<endl;
	delete(aux);
}

void Fila::imprimeFila()
{
	nod*aux=inic;
	if(inic==NULL)
	{
		cout<<"Fila vacia"<<endl;
		cin.get();
		return;
	}
	while(aux!=NULL)
	{
		cout<<aux->dato<<"<-"<<endl;
		aux=aux->pt;
	}
	cin.get();
}

Fila::~Fila()
{
	while(inic!=NULL)
		sacarFila();
}

main()
{
	Fila f1;
	int opc,num;
	do
	{
		cout<<"\n 1. Insertar en la fila ";
		cout<<"\n 2. Sacar de la fila ";
		cout<<"\n 3. Imprime la fila ";
		cout<<"\n 4. Salir \n";
		cin>>opc;
		switch(opc)
		{
			case 1: 
				cout<<"\n Dar un entero: ";
				cin>>num;
				f1.insertarFila(num);
				break;
			case 2:
				f1.sacarFila();
				break;
			case 3:
				f1.imprimeFila();
				break;
			case 4:
				cout<<"\n Fin de ejecucion";
				break;
			default: cout<<"\n Opcion incorrecta";
		}
	}while(opc!=4);
}
